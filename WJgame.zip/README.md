# Frogger Arcade Game aka. Free Tha Carter V

## Summary
Frogger Arcade Game aka. Free Tha Carter V is an arcade game where you have to try to steal back Tha Carter V from Martin Shkreli.

### Goal
The goal in this game is to cross to the other side and snag Tha Carter V from Martin Shkreli away. But be careful, Martin is fast and wants his album back. How many times can you get it away from him? If he catches you, you will start back at zero.

### Controls
Lil Wayne moves up/right/left/down with the arrow keys on the keyboard.

### Installation

1. Download WJgame.zip
2. Unzip the file
3. Open index.html, it will open your browser and the game will get started.